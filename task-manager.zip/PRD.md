# Planning Guide

IkuHub Proyeksi - A comprehensive project management application that helps teams track projects, tasks, team members, and company settings with progress monitoring and status tracking.

**Experience Qualities**: 
1. **Professional** - Clean, corporate-ready interface that instills confidence and supports serious project work
2. **Comprehensive** - Complete visibility into projects, tasks, team members, and company setup without overwhelming users
3. **Collaborative** - Clear assignment tracking and user management that facilitates team coordination

**Complexity Level**: Complex Application (advanced functionality with multiple views)
This is a full-featured project management platform with authentication, multiple management modules (projects, tasks, users, company settings), progress tracking, and role-based views requiring sophisticated state management and multi-view architecture.

## Essential Features

### Login & Authentication
- **Functionality**: Users authenticate to access the application with password validation
- **Purpose**: Secure access and prevent unauthorized entry
- **Trigger**: Application loads without valid session
- **Progression**: Enter credentials → Validate password (must be "Ikuhub@2025") → Store session → Navigate to dashboard
- **Success criteria**: Only correct password grants access, invalid attempts show error message

### Dashboard with Navigation and Value Charts
- **Functionality**: Central hub displaying overview, navigation menu, and project value charts
- **Purpose**: Quick access to all modules, key metrics, and financial overview
- **Trigger**: Successful login or clicking logo/home
- **Progression**: Load dashboard → Display statistics cards → Show project value bar chart by status → Show navigation menu
- **Success criteria**: All modules accessible, chart shows total value and breakdown by status (All, Perencanaan, On Progress, Selesai)

### Project Management
- **Functionality**: Create, view, edit, and delete projects with customer, value, details, auto-calculated progress, and expense tracking
- **Purpose**: Central project tracking with status visibility and budget monitoring
- **Trigger**: Navigate to Projects module
- **Progression**: View project list → Click create/edit → Enter details (name, customer, value, description) → Save → Auto-calculate progress based on tasks → Track expenses against budget
- **Success criteria**: Projects display with correct status (0% = Perencanaan, 1-99% = On Progress, 100% = Selesai), progress updates when tasks change, expenses tracked per project

### Expense Management (within Projects)
- **Functionality**: Create, view, edit, and delete expenses for each project with categories (Petty Cash, Operational, Material, Labor, Other)
- **Purpose**: Track project spending and monitor budget usage
- **Trigger**: Navigate to project detail → Expenses tab
- **Progression**: View expense list → Click add expense → Enter description, amount, category, date → Save → Calculate total against project value
- **Success criteria**: Expenses linked to projects, total calculated correctly, remaining budget displayed

### Task Management (within Projects)
- **Functionality**: Create tasks within projects and assign to users
- **Purpose**: Break down projects into actionable items with clear ownership
- **Trigger**: Navigate to project detail → Tasks tab
- **Progression**: Create task → Assign user(s) → Mark complete/incomplete → Progress updates project automatically
- **Success criteria**: Tasks linked to projects, user assignments visible, completion affects project progress

### User Management
- **Functionality**: Add, edit, and remove team members
- **Purpose**: Maintain team roster for task assignments
- **Trigger**: Navigate to Users module
- **Progression**: View user list → Add new user (name, email, role) → Edit existing → Delete if needed
- **Success criteria**: Users available for task assignment, changes persist

### Company Setup
- **Functionality**: Configure company details, logo, letterhead, and branding
- **Purpose**: Customize application appearance and documents
- **Trigger**: Navigate to Settings/Company module
- **Progression**: Upload logo → Enter company details → Set letterhead template → Save
- **Success criteria**: Company branding appears throughout app, settings persist

## Edge Case Handling
- **Unauthenticated Access**: Redirect to login page for all protected routes
- **Empty States**: Show helpful prompts for empty projects, tasks, and users lists
- **Project Without Tasks**: Progress shows 0%, status "Perencanaan"
- **Task Assignment**: Allow unassigned tasks, show "Unassigned" placeholder
- **User Deletion**: Prevent deletion of users assigned to active tasks, or reassign automatically
- **Invalid Progress**: Recalculate automatically based on task completion ratios
- **Logo Upload**: Validate file types (jpg, png), show preview before saving

## Design Direction
The design should evoke professionalism, efficiency, and clarity - a modern business application that feels powerful yet approachable. Think contemporary SaaS platforms with clean data visualization and intuitive navigation.

## Color Selection
A professional, trustworthy palette that balances corporate sophistication with approachability.

- **Primary Color**: Deep Blue `oklch(0.42 0.15 250)` - Communicates trust, stability, and professionalism; used for primary actions and navigation
- **Secondary Colors**: 
  - Cool Gray `oklch(0.85 0.01 240)` - Subtle backgrounds and card surfaces
  - Slate `oklch(0.35 0.02 240)` - Text and strong contrasts
- **Accent Color**: Energetic Teal `oklch(0.60 0.14 190)` - Progress indicators, success states, and CTAs
- **Foreground/Background Pairings**:
  - Background (Light Gray) `oklch(0.96 0.005 240)`: Slate text `oklch(0.35 0.02 240)` - Ratio 9.8:1 ✓
  - Primary (Deep Blue) `oklch(0.42 0.15 250)`: White text `oklch(1 0 0)` - Ratio 8.2:1 ✓
  - Accent (Energetic Teal) `oklch(0.60 0.14 190)`: White text `oklch(1 0 0)` - Ratio 4.9:1 ✓
  - Card (Cool Gray) `oklch(0.85 0.01 240)`: Slate text `oklch(0.35 0.02 240)` - Ratio 5.2:1 ✓

## Font Selection
Typography should convey clarity and professionalism while maintaining excellent readability for data-heavy interfaces.

**Primary Font**: Inter for all text - modern, highly legible, professional appearance
**Display Font**: Space Grotesk for branding and key headings - adds personality without sacrificing clarity

- **Typographic Hierarchy**:
  - H1 (Page Titles): Space Grotesk Bold/32px/tight letter spacing (-0.01em)
  - H2 (Section Headers): Inter Semibold/24px/normal spacing
  - H3 (Card Titles): Inter Semibold/18px/normal spacing
  - Body Text: Inter Regular/15px/relaxed line height (1.6)
  - UI Labels: Inter Medium/14px/normal spacing
  - Data/Metrics: Inter Semibold/20px for emphasis

## Animations
Animations should be subtle and purposeful, reinforcing state changes without causing delays in a professional environment.

- **Navigation**: Smooth page transitions with subtle fade (150ms) between views
- **Progress Bars**: Animated fill with smooth easing (400ms) when progress updates
- **Task Completion**: Quick checkbox animation (200ms) with progress recalculation
- **Data Loading**: Skeleton loaders for content areas to maintain layout stability
- **Hover States**: Minimal lift on cards (2px, 100ms) and color transitions on buttons
- **Modals/Dialogs**: Scale and fade entrance (200ms) with backdrop blur

## Component Selection

- **Components**:
  - **Card**: Shadcn Card for project cards, user cards, and content containers
  - **Table**: Shadcn Table for project lists and user management
  - **Progress**: Shadcn Progress for project completion visualization
  - **Badge**: Shadcn Badge for status indicators (Perencanaan/On Progress/Selesai)
  - **Dialog**: Shadcn Dialog for create/edit forms
  - **Input/Textarea**: Shadcn form controls for data entry
  - **Select**: Shadcn Select for user assignment and dropdowns
  - **Button**: Shadcn Button for all actions
  - **Avatar**: Shadcn Avatar for user representations
  - **Tabs**: Shadcn Tabs for project detail sections
  - **Separator**: Shadcn Separator for visual divisions
  - **Form**: Shadcn Form with react-hook-form for validation
  
- **Customizations**:
  - Top navbar with logo and navigation menu
  - Project card component showing progress ring/bar
  - Status badge with conditional coloring based on percentage
  - User assignment multi-select component
  - Company logo upload with preview
  - Dashboard metric cards with icons

- **States**:
  - **Buttons**: Scale 0.98 on press, background darkens on hover, disabled is muted
  - **Cards**: Subtle shadow → Enhanced shadow on hover for interactive cards
  - **Progress Bars**: Animate fill changes, color shifts based on percentage
  - **Status Badges**: Color-coded (gray=Perencanaan, blue=On Progress, green=Selesai)
  - **Form Inputs**: Border highlight on focus with accent color

- **Icon Selection** (Phosphor Icons):
  - House/ChartBar for Dashboard
  - FolderOpen for Projects
  - ListChecks for Tasks
  - Users for User Management
  - Gear/Buildings for Company Setup
  - Plus for create actions
  - Pencil for edit
  - Trash for delete
  - UserCircle for user avatars
  - TrendUp for progress

- **Spacing**:
  - Page padding: px-6 py-8
  - Card padding: p-6
  - Grid gaps: gap-6 for cards, gap-4 for forms
  - Section spacing: space-y-6
  - Form field spacing: space-y-4

- **Mobile**:
  - Navbar collapses to hamburger menu
  - Cards stack vertically
  - Tables become scrollable with ScrollArea
  - Dialogs are full-screen on small devices
  - Touch-friendly targets (min 44px)
  - Reduced padding (p-4 on mobile)
